(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 { 
/* button  #btn_footer_menu */
    $(document).on("click", "#btn_footer_menu", function(evt)
    {
         /*global uib_sb */
         /* Other possible functions are: 
           uib_sb.open_sidebar($sb)
           uib_sb.close_sidebar($sb)
           uib_sb.toggle_sidebar($sb)
            uib_sb.close_all_sidebars()
          See js/sidebar.js for the full sidebar API */
        
         uib_sb.toggle_sidebar($("#sidebar_lateral"));  
         return false;
    });
    
        /* button  #btn_footer_home */
    
    
        /* button  #btn_sidebar_provas_marcadas */
    $(document).on("click", "#btn_sidebar_provas_marcadas", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#provas"); 
         return false;
    });
    
        /* button  #btn_sidebar_cadastra_prova */
    
    
        /* button  #btn_sidebar_cadastra_prova */
    $(document).on("click", "#btn_sidebar_cadastra_prova", function(evt)
    {
         /*global activate_page */
         activate_page("#cadastrarProva"); 
         return false;
    });
    
        /* button  #btn_sidebar_fotos */
    $(document).on("click", "#btn_sidebar_fotos", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#fotos"); 
         return false;
    });
    
        /* button  #btn_sidebar_provas_marcadas */
    $(document).on("click", "#btn_sidebar_provas_marcadas", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#provas"); 
         return false;
    });
    
        /* button  #btn_voltar */
    
    
        /* button  #btn_sidebar_provas_marcadas */
    $(document).on("click", "#btn_sidebar_provas_marcadas", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#provas"); 
         return false;
    });
    
        /* button  #btn_footer_home */
    $(document).on("click", "#btn_footer_home", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_2"); 
         return false;
    });
    $(document).on("click", "#btn_marcar", function(evt)
    {
         var id = $("#id_prova").val(),
             disciplina = $("#disciplina").val(),
             professor = $("#professor").val(),
             data = $("#data").val(),
             horario = $("#horario").val(),  
             dado = [],
             transacao = db.transaction("tbl_provas", "readwrite"),
             store = transacao.objectStore("tbl_provas");
        
             dado.ID_PROVA = id;        
             dado.DISCIPLINA = disciplina;
             dado.PROFESSOR = professor;
             dado.DATA = data;
             dado.HORARIO = horario;
        
          var request = store.put(dado);
          
          request.onsuccess = function(event) {
              console.log("Sucesso ao salvar");
          }
          request.onerror = function(event) {
              console.log("Erro ao conectar");
          }
          
          $("#id_prova").val("");
          $("#disciplina").val("");
          $("#professor").val("");
          $("#data").val("");
          $("#horario").val("");
        
          alert("Prova de marcada");
        
          listaProva();
    }); 
     
      $(document).on("click", "#btn_cadastrar", function(evt)
    {
         var //id = $("#id_prova").val(),
             nomeUsuario = $("#campo_nome").val(),
             usuario = $("#campo_user_cadastro").val(),
             senha = $("#campo_senha_cadastro").val(),
             dado = [],
             transacao = db.transaction("tbl_usuarios", "readwrite"),
             store = transacao.objectStore("tbl_usuarios");
        
             dado.NOME_USUARIO = nomeUsuario;        
             dado.USUARIO = usuario;
             dado.SENHA = senha;
        
          var request = store.put(dado);
          
          request.onsuccess = function(event) {
              console.log("Sucesso ao cadastrar");
          }
          request.onerror = function(event) {
              console.log("Erro ao cadastrar");
          }
          
          $("#campo_nome").val("");
          $("#campo_user_cadastro").val("");
          $("#campo_senha_cadastro").val("");
        
          alert("Usuário cadastrado");
        
    });
     
     $(document).on("click", ".glyphicon-remove", function(evt) {
         var codigo = $(this).siblings(".idProva").val();
         var request = db.transaction(["tbl_provas"], "readwrite")
         .objectStore("tbl_provas")
         .delete(codigo);
         request.onsuccess = function(event) {
             console.log("Deletado com sucesso!");
             listaProva();
         };
     });
         
    /* button  #btn_pag_cadastro */
    $(document).on("click", "#btn_pag_cadastro", function(evt)
    {
         /*global activate_page */
         activate_page("#CadastroUsuario"); 
         return false;
    });
    
        /* button  #btn_pag_login */
    $(document).on("click", "#btn_pag_login", function(evt)
    {
         /*global activate_page */
         activate_page("#LoginUsuario"); 
         return false;
    });
    
        /* button  #btn_login_voltar */
    $(document).on("click", "#btn_login_voltar", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #link_pag_cadastro */
    $(document).on("click", "#link_pag_cadastro", function(evt)
    {
         /*global activate_page */
         activate_page("#CadastroUsuario"); 
         return false;
    });
    
        /* button  #link_pag_login */
    $(document).on("click", "#link_pag_login", function(evt)
    {
         /*global activate_page */
         activate_page("#LoginUsuario"); 
         return false;
    });
    
        /* button  #btn_cadastro_voltar */
    $(document).on("click", "#btn_cadastro_voltar", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btn_entrar */
    $(document).on("click", "#btn_entrar", function(evt)
    {
         /*global activate_page */
         activate_page("#PaginaApp"); 
         return false;
    });
    
        /* button  #btn_menu */
    $(document).on("click", "#btn_menu", function(evt)
    {
         /*global uib_sb */
         /* Other possible functions are: 
           uib_sb.open_sidebar($sb)
           uib_sb.close_sidebar($sb)
           uib_sb.toggle_sidebar($sb)
            uib_sb.close_all_sidebars()
          See js/sidebar.js for the full sidebar API */
        
         uib_sb.toggle_sidebar($(".uib_w_44"));  
         return false;
    });
    
        /* button  #btn_pag_app_voltar */
    $(document).on("click", "#btn_pag_app_voltar", function(evt)
    {
         /*global activate_page */
         activate_page("#PaginaApp"); 
         return false;
    });
    
        /* button  #btn_cadastrar_prova */
    $(document).on("click", "#btn_cadastrar_prova", function(evt)
    {
         /*global activate_page */
         activate_page("#cadastrarProva"); 
         return false;
    });
    
        /* button  #btn_voltar */
    $(document).on("click", "#btn_voltar", function(evt)
    {
         /*global activate_page */
         activate_page("#PaginaApp"); 
         return false;
    });
    
        /* button  #btn_provas */
    $(document).on("click", "#btn_provas", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#Provas"); 
         return false;
    });
    
        /* button  #btn_pag_app_home */
    $(document).on("click", "#btn_pag_app_home", function(evt)
    {
         /*global activate_page */
         activate_page("#PaginaApp"); 
         return false;
    });
    
        /* button  #btn_fotos */
    $(document).on("click", "#btn_fotos", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#Fotos"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();

function listaProva() {
    $("#lista_prova").html("");
    var array = [];
    var objectStore = db.transaction("tbl_provas").objectStore("tbl_provas");
    objectStore.openCursor().onsuccess = function(event) {
        var cursor = event.target.result;
        if(cursor) {
            array.push(cursor.value);
            cursor.continue();
        }
        else {
            var tamanho = array.length;
            console.log(array);
            for(var i = 0; i < tamanho; i++) {
                $("#lista_prova").append('<a class="list-group-item allow-badge widget uib_w_19" data-uib="twitter%20bootstrap/list_item" data-ver="0"><p class="list-group-item-text"><i class="glyphicon glyphicon-remove pull-right"></i>'+array[i].DISCIPLINA+'<input class="idProva" value"'+array[i].ID_PROVA+'" hidden="hidden"></p><p class="list-group-item-text">'+array[i].PROFESSOR+'</p><p class="list-group-item-text">'+array[i].DATA+'</p><p class="list-group-item-text">'+array[i].HORARIO+'</p></a>');  
            }
        }
    };
}