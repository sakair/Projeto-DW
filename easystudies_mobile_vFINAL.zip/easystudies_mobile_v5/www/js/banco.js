if (!window.indexedDB) {
    window.alert("Seu navegador não suporta a versão estável do indexedDB. Algumas features poderão não funcionar.");
} else {
    
// Criar banco de dados
    var request = indexedDB.open("projeto_dw", 3);
    var db = null;    
    request.onupgradeneeded = function() {
        db = request.result;
        
        var prova = db.createObjectStore("tbl_provas", {keyPath : 'ID_PROVA'});
        
        //prova.createIndex("ID_PROVA", "ID_PROVA", {unique : true});
        prova.createIndex("DISCIPLINA", "DISCIPLINA", {unique : false});
        prova.createIndex("PROFESSOR", "PROFESSOR", {unique : false});
        prova.createIndex("DATA", "DATA", {unique : false});
        prova.createIndex("HORARIO", "HORARIO", {unique : false});
        
        var usuarios = db.createObjectStore("tbl_usuarios", {keyPath : 'ID_USUARIO', autoIncrement : true});
        
        usuarios.createIndex("ID_USUARIO", "ID_USUARIO", {unique : true});
        usuarios.createIndex("NOME_USUARIO", "NOME_USUARIO", {unique : false});
        usuarios.createIndex("USUARIO", "USUARIO", {unique : true});
        usuarios.createIndex("SENHA", "SENHA", {unique : false});

        }
    request.onsucess = function() {
        db = request.result;
        console.log(db);
        console.log("Conectado");
    }
    request.onerror = function(event) {
        console.log("Erro ao conectar");
    }
}
